STEP 10 - ANNOUNCEMENTS TO MONGODB

This step DOES NOT add a new API file.
It reuses:
api/admin-dashboard.js

Why?
Vercel Hobby plan only allows 12 Serverless Functions. So announcements are handled inside admin-dashboard.js.

Replace these files in GitHub:
- app.js
- public/app.js
- admin-announcements.html
- public/admin-announcements.html
- api/admin-dashboard.js

After upload:
1. Commit changes.
2. Wait Vercel deployment until Ready.
3. Test:
   https://vansytem-sec.vercel.app/api/admin-dashboard?action=announcements

Correct result:
{
  "success": true,
  "announcements": [],
  "summary": {...}
}

Then:
1. Open admin-announcements.html
2. Post an announcement.
3. Check MongoDB -> announcements collection.
4. Parent dashboard should show active announcements after refresh.

Do NOT add new API files for announcements, or Vercel may fail because of the 12-function limit.
